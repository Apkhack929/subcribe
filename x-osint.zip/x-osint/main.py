import argparse
import sys
import os
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich import print as rprint

# Add the current directory to sys.path to allow imports from modules
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from modules.username_checker import check_username
from modules.domain_analyzer import analyze_domain
from modules.port_scanner import scan_ports

console = Console()

def display_banner():
    banner = """
    [bold cyan]
    __   __      ____   _____ ___ _   _ _____ 
    \ \ / /     / __ \ / ____|_ _| \ | |_   _|
     \ V /_____| |  | | (___  | ||  \| | | |  
      > <______| |  | |\___ \ | || . ` | | |  
     / ^ \     | |__| |____) || || |\  |_| |_ 
    /_/ \_\     \____/|_____/___|_| \_|_____|
    [/bold cyan]
    [bold yellow]v1.0 - Open Source Intelligence Analyzer[/bold yellow]
    """
    rprint(Panel(banner, border_style="cyan"))

def handle_username(username):
    rprint(f"[bold cyan][*][/bold cyan] Scanning username: [bold yellow]{username}[/bold yellow]...")
    results = check_username(username)
    
    table = Table(title=f"Username Search Results for '{username}'")
    table.add_column("Platform", style="cyan")
    table.add_column("Status", style="magenta")
    table.add_column("URL", style="blue")

    for platform, info in results.items():
        status_style = "green" if info["status"] == "Found" else "red"
        table.add_row(platform, f"[{status_style}]{info['status']}[/{status_style}]", info["url"])
    
    console.print(table)

def handle_domain(domain):
    rprint(f"[bold cyan][*][/bold cyan] Analyzing domain: [bold yellow]{domain}[/bold yellow]...")
    results = analyze_domain(domain)
    
    # WHOIS Section
    whois_table = Table(title=f"WHOIS Information for '{domain}'")
    whois_table.add_column("Field", style="cyan")
    whois_table.add_column("Value", style="magenta")

    whois_data = results.get("whois", {})
    if "error" in whois_data:
        whois_table.add_row("Error", str(whois_data["error"]))
    else:
        for field, value in whois_data.items():
            whois_table.add_row(field.capitalize(), str(value))
    
    console.print(whois_table)

    # DNS Section
    dns_table = Table(title=f"DNS Records for '{domain}'")
    dns_table.add_column("Type", style="cyan")
    dns_table.add_column("Records", style="magenta")

    dns_data = results.get("dns", {})
    for record_type, records in dns_data.items():
        dns_table.add_row(record_type, ", ".join(records) if records else "No records found")
    
    console.print(dns_table)

def handle_ports(target):
    rprint(f"[bold cyan][*][/bold cyan] Scanning common ports on: [bold yellow]{target}[/bold yellow]...")
    results = scan_ports(target)
    
    table = Table(title=f"Open Ports on '{target}'")
    table.add_column("Port", style="cyan")
    table.add_column("Status", style="green")
    table.add_column("Service", style="magenta")

    if not results:
        table.add_row("N/A", "No common ports open", "N/A")
    else:
        for port, status, service in results:
            table.add_row(str(port), status, service)
    
    console.print(table)
    
    if len(results) > 10:
        rprint("[bold yellow][!] Warning:[/bold yellow] Many ports are open. This might be due to a transparent proxy or firewall.")

def main():
    parser = argparse.ArgumentParser(description="X-OSINT: Open Source Intelligence Analyzer")
    parser.add_argument("-u", "--username", help="Check username across social media platforms")
    parser.add_argument("-d", "--domain", help="Analyze domain (WHOIS and DNS)")
    parser.add_argument("-p", "--port", help="Scan common ports on a target host/domain")
    parser.add_argument("-a", "--all", help="Perform all checks on a target (if applicable)")

    if len(sys.argv) == 1:
        display_banner()
        parser.print_help()
        sys.exit(1)

    args = parser.parse_args()
    display_banner()

    if args.username:
        handle_username(args.username)
    
    if args.domain:
        handle_domain(args.domain)
        # If domain is provided, also offer port scan if requested
        if args.port:
             handle_ports(args.domain)
    elif args.port:
        handle_ports(args.port)

    if args.all:
        # Treat 'all' as a target for both username and domain/port
        handle_username(args.all)
        handle_domain(args.all)
        handle_ports(args.all)

if __name__ == "__main__":
    main()
