# X-OSINT: Open Source Intelligence Analyzer

A powerful and simple OSINT tool built in Python to perform common reconnaissance tasks.

## Features

- **Username Checker**: Scans 10+ social media platforms for a specific username.
- **Domain Analyzer**: Performs WHOIS lookups and retrieves DNS records (A, AAAA, MX, TXT, NS).
- **Port Scanner**: Identifies open common ports on a target host and detects potential services.

## Installation

1. Install system dependencies:
   ```bash
   sudo apt-get update && sudo apt-get install -y whois
   ```

2. Install Python dependencies:
   ```bash
   pip install whois dnspython requests rich
   ```

## Usage

Run the tool using `python3 main.py` with the following arguments:

- `-u`, `--username`: Check a username across platforms.
- `-d`, `--domain`: Analyze a domain (WHOIS and DNS).
- `-p`, `--port`: Scan common ports on a target host/domain.
- `-a`, `--all`: Perform all checks on a target.

### Examples

Check a username:
```bash
python3 main.py -u johndoe
```

Analyze a domain:
```bash
python3 main.py -d example.com
```

Scan ports:
```bash
python3 main.py -p 127.0.0.1
```

Perform all checks on a target:
```bash
python3 main.py -a example.com
```

## Structure

- `main.py`: CLI interface and main logic.
- `modules/`:
  - `username_checker.py`: Username scanning logic.
  - `domain_analyzer.py`: WHOIS and DNS analysis.
  - `port_scanner.py`: Port scanning and service detection.
