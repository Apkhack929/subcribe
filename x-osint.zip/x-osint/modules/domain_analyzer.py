import whois
import dns.resolver

def analyze_domain(domain):
    results = {
        "whois": {},
        "dns": {}
    }

    # WHOIS Lookup
    try:
        # Using whois.query for the 'whois' library
        w = whois.query(domain)
        if w:
            results["whois"] = {
                "registrar": getattr(w, 'registrar', 'N/A'),
                "creation_date": str(getattr(w, 'creation_date', 'N/A')),
                "expiration_date": str(getattr(w, 'expiration_date', 'N/A')),
                "name_servers": getattr(w, 'name_servers', 'N/A'),
                "org": getattr(w, 'org', 'N/A'),
                "country": getattr(w, 'country', 'N/A')
            }
        else:
            results["whois"] = {"error": "No WHOIS data found"}
    except Exception as e:
        results["whois"] = {"error": str(e)}

    # DNS Records
    record_types = ["A", "AAAA", "MX", "TXT", "NS"]
    for record_type in record_types:
        try:
            answers = dns.resolver.resolve(domain, record_type)
            results["dns"][record_type] = [str(rdata) for rdata in answers]
        except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN, dns.resolver.NoNameservers, Exception):
            results["dns"][record_type] = []

    return results
