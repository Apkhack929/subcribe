import requests

def check_username(username):
    platforms = {
        "Instagram": f"https://www.instagram.com/{username}/",
        "Twitter/X": f"https://twitter.com/{username}",
        "GitHub": f"https://github.com/{username}",
        "Facebook": f"https://www.facebook.com/{username}",
        "Reddit": f"https://www.reddit.com/user/{username}",
        "YouTube": f"https://www.youtube.com/@{username}",
        "TikTok": f"https://www.tiktok.com/@{username}",
        "Pinterest": f"https://www.pinterest.com/{username}/",
        "Snapchat": f"https://www.snapchat.com/add/{username}",
        "Twitch": f"https://www.twitch.tv/{username}"
    }

    results = {}
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }

    for platform, url in platforms.items():
        try:
            # Note: Some platforms (like Instagram/Twitter) may require more complex checks or APIs.
            # This is a basic implementation using HTTP status codes.
            response = requests.get(url, headers=headers, timeout=5, allow_redirects=True)
            if response.status_code == 200:
                results[platform] = {"status": "Found", "url": url}
            elif response.status_code == 404:
                results[platform] = {"status": "Not Found", "url": url}
            else:
                results[platform] = {"status": f"Unknown ({response.status_code})", "url": url}
        except requests.exceptions.RequestException:
            results[platform] = {"status": "Request Failed", "url": url}

    return results
