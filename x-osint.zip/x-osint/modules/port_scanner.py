import socket
from concurrent.futures import ThreadPoolExecutor

def scan_port(target, port):
    try:
        # Use a socket to check if a port is open
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1.0)
            result = s.connect_ex((target, port))
            if result == 0:
                try:
                    # Attempt to get the service name for the port
                    service = socket.getservbyport(port)
                except (socket.error, OverflowError):
                    service = "Unknown"
                return port, "Open", service
            else:
                return port, "Closed", None
    except Exception:
        return port, "Error", None

def scan_ports(target, ports=None):
    if ports is None:
        # Standard common ports for OSINT/security scanning
        ports = [21, 22, 23, 25, 53, 80, 110, 143, 443, 3306, 3389, 8080]

    results = []
    # Use ThreadPoolExecutor for faster scanning
    with ThreadPoolExecutor(max_workers=10) as executor:
        futures = [executor.submit(scan_port, target, port) for port in ports]
        for future in futures:
            port_info = future.result()
            if port_info[1] == "Open":
                results.append(port_info)

    return results
